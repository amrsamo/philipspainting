<?php
/**
 * The template to display the featured image in the single post
 *
 * @package WordPress
 * @subpackage PRORANGE
 * @since PRORANGE 1.0
 */

?>